<?php
$dbHost = "localhost";
$dbUser = "";
$dbPW = "";
$dbName = "";
$mysqli = mysqli_connect($dbHost, $dbUser, $dbPW, $dbName);
if(mysqli_connect_errno()){
	echo "Failed to connect to MySQL: " . mysqli_connect_error();
}

// basic info
$faucet['name'] = 'CoinBox.Club';
$faucet['description'] = 'Free Coin';
$currency = 'BTC';
$currency_name = 'satoshi';
$faucet['captcha'] = 2; // 1 for bitcaptcha and 2 for recaptcha
// bitcaptcha setting
$bitcaptcha['id'] = '';
$bitcaptcha['key'] = '';


//recaptcha setting
$secretkey = ''; // your recaptcha private key
$publickey = ''; // your recaptcha public key

// iphub setting, use it to block proxy. get your api at iphub.info
$iphub_api = '';

// config your reward
$faucet['reward'] = 15; // your faucet's reward
$faucet['time'] = 600;  // time to wait beetwen 2 claims, in second.
$faucet['ref'] = 15;
$faucet['url'] = 'http://coinbox.club/demo';

$faucethub_api = "";

// config your short link, read full instruction at http://coinbox.club/
$config_link['status'] = 'on'; // turn on or off short link bounus
$config_link['reward'] = 30; // short link bounus amout
     //  start config short link api
$link[1] = "http://coin.mg/api/?api=acefbf14f0e9b8cee80cd05035facade0530fd1e&url=http://coinbox.club/demo/link.php?k={key}&format=text";

$link[2] = "http://btc.ms/api/?api=86b6c147ce28028e5c7762afce1656f898279889&url=http://coinbox.club/demo/link.php?k={key}&format=text";

$link[4] = "http://btc.ms/api/?api=86b6c147ce28028e5c7762afce1656f898279889&url=http://coinbox.club/demo/link.php?k={key}&format=text";

$link[3] = "https://madpay.net/api/?api=90720ad27f78aa8777bd69400270f6e7c243b474&url=http://coinbox.club/demo/link.php?k={key}&format=text";

$link[5] = "https://madpay.net/api/?api=90720ad27f78aa8777bd69400270f6e7c243b474&url=http://coinbox.club/demo/link.php?k={key}&format=text";

// ad spaces
$ad['top'] = '<img src="http://placehold.it/728x90">';
$ad['left'] = '<img src="http://placehold.it/160x600">';
$ad['right'] = '<img src="http://placehold.it/160x600">';
$ad['above-form'] = '<img src="http://placehold.it/468x60">';
$ad['bottom'] = '<img src="http://placehold.it/300x250">';
?>   