<?php
session_start();
include 'config.php';
include 'function.php';
$ip = get_ip();
$time = time();
?>