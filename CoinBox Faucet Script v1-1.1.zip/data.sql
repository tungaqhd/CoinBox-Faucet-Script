-- phpMyAdmin SQL Dump
-- version 4.0.10.14
-- http://www.phpmyadmin.net
--
-- Client: localhost:3306
-- Généré le: Mar 12 Septembre 2017 à 01:52
-- Version du serveur: 10.1.24-MariaDB-cll-lve
-- Version de PHP: 5.6.20

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8 */;

--
-- Base de données: `bigfxegj_script`
--

-- --------------------------------------------------------

--
-- Structure de la table `address_list`
--

CREATE TABLE IF NOT EXISTS `address_list` (
  `id` int(32) unsigned NOT NULL AUTO_INCREMENT,
  `bitcoin_address` varchar(75) NOT NULL,
  `ref` varchar(75) NOT NULL,
  `last` int(32) NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=MyISAM  DEFAULT CHARSET=latin1 AUTO_INCREMENT=5 ;
 
CREATE TABLE IF NOT EXISTS `ip_list` (
  `id` int(32) unsigned NOT NULL AUTO_INCREMENT,
  `ip_address` varchar(50) NOT NULL,
  `last` int(32) NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=MyISAM  DEFAULT CHARSET=latin1 AUTO_INCREMENT=5 ;
 

CREATE TABLE IF NOT EXISTS `link` (
  `bitcoin_address` varchar(75) NOT NULL,
  `sec_key` varchar(75) NOT NULL
) ENGINE=MyISAM DEFAULT CHARSET=latin1; 

/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
