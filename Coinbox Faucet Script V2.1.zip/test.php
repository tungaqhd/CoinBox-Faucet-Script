<?php

include 'libs/core.php'; 
if (isset($_POST['sqn_captcha'])) { echo $_POST['sqn_captcha'];
if(sqn_validate($_POST['sqn_captcha'], $bitcaptcha_key, $bitcaptcha_id)) {
    // verification success
			} else {
				echo 0;
			}
} else { echo 1; }
?>
<center>
<form action="" method="post"> 
<input type="hidden" name="sqn_captcha" id="sqn_captcha" value="Token" />
<button type="submit" id="login_btn">ok</button>
<p onclick='check()'>lll</p>
</form></center>
<script src="//static.shenqiniao.net/sqn.js?id=10000001187&btn=login_btn" type="text/javascript"></script>
	<script src="https://code.jquery.com/jquery-3.2.1.slim.min.js" integrity="sha384-KJ3o2DKtIkvYIK3UENzmM7KCkRr/rE9/Qpg6aAZGJwFDMVNA/GpGFF93hXpG5KkN" crossorigin="anonymous"></script>
<script>
function check() { var captcha = $('#sqn_captcha').val(); alert(captcha); } </script>